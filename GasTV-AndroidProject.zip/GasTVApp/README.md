# GasTV APK - WebView App untuk gasstv.pw

## 📱 Cara Build APK

### Metode 1: Android Studio (Direkomendasikan)
1. Install **Android Studio** dari https://developer.android.com/studio
2. Buka folder project ini di Android Studio
3. Tunggu Gradle sync selesai
4. Klik **Build > Build Bundle(s) / APK(s) > Build APK(s)**
5. APK ada di: `app/build/outputs/apk/debug/app-debug.apk`

### Metode 2: Command Line
```bash
# Pastikan JAVA_HOME sudah di-set
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

## ✅ Fitur APK
- WebView penuh ke gasstv.pw
- **Deep link**: Buka gasstv.pw dari browser → langsung masuk app
- Swipe ke bawah untuk refresh
- Progress bar merah saat loading
- Video fullscreen support
- Halaman offline jika tidak ada internet
- Back button → navigasi mundur dalam web

## 📋 Requirements
- Android 5.0+ (minSdk 21)
- Target Android 14 (targetSdk 34)

## 🔗 Deep Link Setup
Setelah install APK, ketika pengguna buka **gasstv.pw** di browser,
Android akan menawarkan untuk membuka via app GasTV.
