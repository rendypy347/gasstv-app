package com.df21.live

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefresh: SwipeRefreshLayout

    private val TARGET_URL = "https://sbotv.live"
    private val FILE_CHOOSER_REQUEST = 1001
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // Popup WebView dialog (untuk window.open / target=_blank)
    private var popupWindow: android.app.Dialog? = null
    private var popupWebView: WebView? = null

    // Whitelist domain yang boleh dibuka di dalam WebView (load di main view).
    // - sbotv.live  : landing page utama APK
    // - df21.biz.id : situs film, series, live streaming bola
    // - gasstv.pw   : legacy domain (redirect ke df21.biz.id)
    // - sbotv.my.id / sbotv.biz.id : server streaming m3u8
    private val ALLOWED_HOSTS = listOf(
        "sbotv.live",
        "df21.biz.id",
        "gasstv.pw",
        "sbotv.my.id",
        "sbotv.biz.id"
    )

    // Custom URL scheme dari aplikasi pihak ketiga yang TIDAK boleh trigger
    // crash kalau aplikasinya tidak terinstall (Shopee, Tokopedia, YouTube, dsb).
    // Daftar ini untuk pengecekan eksplisit + log; selain http/https semua
    // tetap di-handle oleh `handleExternalScheme()`.
    private val EXTERNAL_SCHEMES = listOf(
        "intent:", "market:", "tel:", "sms:", "mailto:", "geo:", "whatsapp:",
        "shopee:", "shopeeid:", "tokopedia:", "tokopedia-android-internal:",
        "youtube:", "vnd.youtube:", "fb:", "fb-messenger:", "tg:",
        "instagram:", "twitter:", "tiktok:", "snssdk:", "line:",
        "gojek:", "grab:", "ovo:", "dana:", "gopay:", "blibli:", "lazada:"
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)
        progressBar = findViewById(R.id.progressBar)
        swipeRefresh = findViewById(R.id.swipeRefresh)

        setupWebView(webView, isPopup = false)

        // Swipe to refresh - merah brand DF21
        swipeRefresh.setColorSchemeColors(Color.parseColor("#E74C3C"))
        swipeRefresh.setOnRefreshListener { webView.reload() }

        // Back button: tutup popup dulu, baru navigate webview, baru exit
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (popupWindow?.isShowing == true) {
                    closePopup()
                    return
                }
                if (webView.canGoBack()) webView.goBack()
                else finish()
            }
        })

        webView.loadUrl(TARGET_URL)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView(wv: WebView, isPopup: Boolean) {
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            // User agent: pakai default + tambah identifier app
            userAgentString = userAgentString.replace("wv", "") + " DF21Live/1.0"
        }

        wv.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                if (!isPopup) progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String) {
                if (!isPopup) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                }
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                return handleUrlLoading(view, request.url.toString(), isPopup)
            }

            // Fallback untuk Android < 24 (some redirects masih lewat ini)
            @Suppress("OverridingDeprecatedMember", "DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return handleUrlLoading(view, url, isPopup)
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                if (request.isForMainFrame && !isPopup) {
                    view.loadData(offlineHtml(), "text/html", "UTF-8")
                }
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            private var customView: View? = null
            private var customViewCallback: CustomViewCallback? = null
            private var originalOrientation = 0

            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (!isPopup) progressBar.progress = newProgress
            }

            // window.open / target="_blank" → buka popup di dalam app
            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message
            ): Boolean {
                showPopupWebView(resultMsg = resultMsg)
                return true
            }

            override fun onCloseWindow(window: WebView) {
                closePopup()
            }

            // Fullscreen video (HTML5 video)
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                customView = view
                customViewCallback = callback
                originalOrientation = requestedOrientation
                val decor = window.decorView as FrameLayout
                decor.addView(customView, FrameLayout.LayoutParams(-1, -1))
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
            }

            override fun onHideCustomView() {
                customView?.let { (window.decorView as FrameLayout).removeView(it) }
                customView = null
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
                requestedOrientation = originalOrientation
                customViewCallback?.onCustomViewHidden()
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePath: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                filePathCallback?.onReceiveValue(null)
                filePathCallback = filePath
                try {
                    startActivityForResult(fileChooserParams.createIntent(), FILE_CHOOSER_REQUEST)
                } catch (e: Exception) {
                    filePathCallback = null
                    return false
                }
                return true
            }

            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
                result.confirm(); return true
            }
        }
    }

    /**
     * Inti dari handling URL — dipanggil dari shouldOverrideUrlLoading.
     *
     * Aturan:
     * 1. URL kosong / null → biarkan default (return false).
     * 2. URL http/https ke domain whitelist → load di WebView (return false).
     * 3. URL http/https ke domain LAIN → buka di browser eksternal kalau bisa,
     *    kalau gagal → ignore (jangan crash).
     * 4. URL custom scheme (intent://, shopee://, tokopedia://, dll.) →
     *    coba buka aplikasi target. Kalau gagal (ANR / aplikasi belum
     *    terinstall) → JANGAN crash, JANGAN redirect ke Play Store yang
     *    annoying, cukup return true (block) supaya WebView nggak coba load
     *    URL tersebut sebagai halaman.
     *
     * Return true = WebView berhenti, kita yang handle.
     * Return false = WebView lanjut load URL tersebut sendiri.
     */
    private fun handleUrlLoading(view: WebView, url: String, isPopup: Boolean): Boolean {
        if (url.isEmpty()) return false

        val lower = url.lowercase()

        // -------- HTTP / HTTPS --------
        if (lower.startsWith("http://") || lower.startsWith("https://")) {
            // Kalau ini dipanggil dari WebView popup, biarkan apa pun
            // load di popup yang sama — jangan spawn popup di atas popup.
            if (isPopup) return false

            val host = try { Uri.parse(url).host ?: "" } catch (e: Exception) { "" }
            val isAllowed = ALLOWED_HOSTS.any { allowed ->
                host == allowed || host.endsWith(".$allowed")
            }
            if (isAllowed) {
                // Domain whitelist (df21, gasstv, sbotv) → load di main WebView
                return false
            }

            // Domain luar (iklan popunder, search redirect Google, social, dsb.)
            // → BUKA DI POPUP DALAM APP, bukan browser eksternal.
            // Kalau popup sudah terbuka, load di popup yang sama supaya
            // tidak ada nested popup.
            if (popupWindow?.isShowing == true) {
                popupWebView?.loadUrl(url)
            } else {
                showPopupWebView(url = url)
            }
            return true
        }

        // -------- CUSTOM SCHEME (popunder ads target apps) --------
        // Contoh: shopee://, tokopedia://, intent://, market://, youtube://
        return handleExternalScheme(url)
    }

    /**
     * Handle URL dengan scheme non-http (intent://, shopee://, dll.)
     * Selalu return true agar WebView TIDAK mencoba load URL tersebut sebagai
     * halaman web (yang akan menyebabkan error / crash di sebagian Android).
     */
    private fun handleExternalScheme(url: String): Boolean {
        try {
            // Khusus intent:// pakai parser bawaan Android (lebih akurat,
            // bisa parse fallback URL juga)
            if (url.startsWith("intent:", ignoreCase = true) ||
                url.startsWith("android-app:", ignoreCase = true)
            ) {
                val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                // Coba buka aplikasi targetnya
                try {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                    return true
                } catch (e: ActivityNotFoundException) {
                    // App tidak terinstall — coba fallback URL kalau ada
                    val fallback = intent.getStringExtra("browser_fallback_url")
                    if (!fallback.isNullOrEmpty()) {
                        webView.loadUrl(fallback)
                    }
                    // Tidak ada fallback → cukup block (return true)
                    return true
                }
            }

            // Scheme generic (shopee://, youtube://, tokopedia://, market://, dll.)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Log.d("DF21Live", "App not installed for: $url")
            // App tidak terinstall — diam saja, jangan crash
        } catch (e: Exception) {
            Log.d("DF21Live", "Error handling URL $url: ${e.message}")
            // Apapun error lainnya — jangan biarkan app crash
        }
        // Selalu return true: kita sudah handle (atau sudah ignore),
        // WebView nggak boleh coba load URL custom-scheme tersebut.
        return true
    }

    // -------- POPUP MODAL (target=_blank / window.open / external URL) --------
    /**
     * Tampilkan popup WebView modal.
     *
     * Dipanggil dari 2 entry point:
     *  1. `onCreateWindow()` — saat web pakai window.open / target=_blank.
     *     Kasus ini WAJIB pakai `resultMsg` agar JS engine kebagian referensi
     *     ke WebView baru (tanpa itu, halaman pemanggil bisa hang menunggu).
     *  2. `handleUrlLoading()` — saat redirect ke domain luar (iklan
     *     popunder ke google.com dll.). Kasus ini pakai `url` langsung.
     */
    @SuppressLint("SetJavaScriptEnabled")
    private fun showPopupWebView(
        resultMsg: android.os.Message? = null,
        url: String? = null
    ) {
        val dialog = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.parseColor("#CC000000")))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setGravity(Gravity.CENTER)
        }

        // Root: tap di luar popup = close
        val rootLayout = FrameLayout(this)
        rootLayout.setBackgroundColor(Color.parseColor("#AA000000"))
        rootLayout.setOnClickListener { closePopup() }

        // Card popup (di tengah)
        val cardLayout = FrameLayout(this)
        cardLayout.setBackgroundColor(Color.parseColor("#141414"))
        cardLayout.elevation = 24f

        val cardParams = FrameLayout.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.93).toInt(),
            (resources.displayMetrics.heightPixels * 0.85).toInt()
        )
        cardParams.gravity = Gravity.CENTER
        cardLayout.layoutParams = cardParams
        // Cegah tap di card menutup popup
        cardLayout.setOnClickListener { /* consume */ }

        // Progress bar popup
        val popupProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        popupProgress.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, 6
        )
        popupProgress.progressTintList =
            android.content.res.ColorStateList.valueOf(Color.parseColor("#E74C3C"))

        // WebView popup
        val newWebView = WebView(this)
        newWebView.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        setupWebView(newWebView, isPopup = true)

        // Override chrome client untuk update progress popup
        newWebView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                popupProgress.progress = newProgress
                popupProgress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }

            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message
            ): Boolean {
                // Link di dalam popup → buka di popup yang sama
                val transport = resultMsg.obj as WebView.WebViewTransport
                transport.webView = newWebView
                resultMsg.sendToTarget()
                return true
            }
        }

        // Tombol close (X)
        val closeBtn = TextView(this)
        closeBtn.text = "✕"
        closeBtn.textSize = 20f
        closeBtn.setTextColor(Color.WHITE)
        closeBtn.setBackgroundColor(Color.parseColor("#E74C3C"))
        val closeBtnParams = FrameLayout.LayoutParams(dpToPx(44), dpToPx(44))
        closeBtnParams.gravity = Gravity.TOP or Gravity.END
        closeBtn.layoutParams = closeBtnParams
        closeBtn.gravity = Gravity.CENTER
        closeBtn.setOnClickListener { closePopup() }

        // Susun
        cardLayout.addView(newWebView)
        cardLayout.addView(popupProgress)
        cardLayout.addView(closeBtn)
        rootLayout.addView(cardLayout)
        dialog.setContentView(rootLayout)

        // Attach: tergantung dari mana popup dipanggil
        if (resultMsg != null) {
            // Dari window.open / target=_blank → bridge via WebViewTransport
            val transport = resultMsg.obj as WebView.WebViewTransport
            transport.webView = newWebView
            resultMsg.sendToTarget()
        } else if (url != null) {
            // Dari redirect domain luar → load URL langsung
            newWebView.loadUrl(url)
        }

        popupWebView = newWebView
        popupWindow = dialog
        dialog.show()
    }

    private fun closePopup() {
        try { popupWebView?.destroy() } catch (e: Exception) { /* ignore */ }
        popupWebView = null
        try { popupWindow?.dismiss() } catch (e: Exception) { /* ignore */ }
        popupWindow = null
    }

    private fun dpToPx(dp: Int): Int =
        (dp * resources.displayMetrics.density).toInt()

    // -------- ROTATION HANDLING --------
    // Karena kita declare configChanges di manifest, sistem TIDAK akan
    // recreate Activity saat rotasi. Kita di sini cuma log-friendly.
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // WebView otomatis re-layout. Tidak perlu apa-apa lagi.
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            val result = if (resultCode == Activity.RESULT_OK && data != null)
                WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onResume() { super.onResume(); webView.onResume() }
    override fun onPause() { super.onPause(); webView.onPause() }
    override fun onDestroy() {
        closePopup()
        webView.destroy()
        super.onDestroy()
    }

    private fun offlineHtml() = """
        <!DOCTYPE html><html><head><meta charset=UTF-8>
        <meta name=viewport content='width=device-width,initial-scale=1'>
        <style>
          body{background:#0a0a0a;color:#e0e0e0;font-family:sans-serif;
            display:flex;flex-direction:column;align-items:center;
            justify-content:center;min-height:100vh;margin:0;text-align:center;padding:24px}
          .icon{font-size:64px;margin-bottom:16px}
          h2{color:#fff;margin-bottom:8px}
          p{color:#666;margin-bottom:24px;line-height:1.6}
          button{background:#e74c3c;color:#fff;border:none;border-radius:10px;
            padding:14px 28px;font-size:16px;font-weight:700;cursor:pointer}
        </style></head><body>
        <div class=icon>📡</div>
        <h2>Tidak Ada Koneksi</h2>
        <p>Periksa koneksi internet kamu<br>lalu coba lagi.</p>
        <button onclick='location.reload()'>🔄 Coba Lagi</button>
        </body></html>
    """.trimIndent()
}
