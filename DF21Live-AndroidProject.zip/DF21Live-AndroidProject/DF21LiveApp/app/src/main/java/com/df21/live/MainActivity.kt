package com.df21.live

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.webkit.*
import android.widget.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.net.URISyntaxException

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var swipeRefresh: SwipeRefreshLayout

    private val TARGET_URL = "https://sbotv.live"
    private val FILE_CHOOSER_REQUEST = 1001
    private var filePathCallback: ValueCallback<Array<Uri>>? = null

    // Popup WebView dialog (untuk window.open / target=_blank)
    private var popupWindow: android.app.Dialog? = null
    private var popupWebView: WebView? = null

    // Whitelist domain yang boleh dibuka di dalam WebView (load di main view).
    // - sbotv.live  : landing page utama APK
    // - df21.biz.id : situs film, series, live streaming bola
    // - gasstv.pw   : legacy domain (redirect ke df21.biz.id)
    // - sbotv.my.id / sbotv.biz.id : server streaming m3u8
    private val ALLOWED_HOSTS = listOf(
        "sbotv.live",
        "df21.biz.id",
        "gasstv.pw",
        "sbotv.my.id",
        "sbotv.biz.id",
        "df21-1.biz.id",
        "df21-2.biz.id",
        "df21-3.biz.id",
        "df21-4.biz.id",
        "df21-5.biz.id",
        "df21-6.biz.id",
        "df21-7.biz.id",
        "df21-8.biz.id",
        "df21-9.biz.id",
        "df21-10.biz.id",
        "df21-11.biz.id",
        "df21-12.biz.id",
        "df21-13.biz.id",
        "df21-14.biz.id",
        "df21-15.biz.id",
        "df21-16.biz.id",
        "df21-17.biz.id",
        "df21-18.biz.id",
        "df21-19.biz.id",
        "df21-20.biz.id",
        "df21-21.biz.id",
        "df21-22.biz.id",
        "df21-23.biz.id",
        "df21-24.biz.id",
        "df21-25.biz.id",
        "df21-26.biz.id",
        "df21-27.biz.id",
        "df21-28.biz.id",
        "df21-29.biz.id",
        "df21-30.biz.id",
        "df21-31.biz.id",
        "df21-32.biz.id",
        "df21-33.biz.id",
        "df21-34.biz.id",
        "df21-35.biz.id",
        "df21-36.biz.id",
        "df21-37.biz.id",
        "df21-38.biz.id",
        "df21-39.biz.id",
        "df21-40.biz.id",
        "df21-41.biz.id",
        "df21-42.biz.id",
        "df21-43.biz.id",
        "df21-44.biz.id",
        "df21-45.biz.id",
        "df21-46.biz.id",
        "df21-47.biz.id",
        "df21-48.biz.id",
        "df21-49.biz.id",
        "df21-50.biz.id",
        "df21-51.biz.id",
        "df21-52.biz.id",
        "df21-53.biz.id",
        "df21-54.biz.id",
        "df21-55.biz.id",
        "df21-56.biz.id",
        "df21-57.biz.id",
        "df21-58.biz.id",
        "df21-59.biz.id",
        "df21-60.biz.id",
        "df21-61.biz.id",
        "df21-62.biz.id",
        "df21-63.biz.id",
        "df21-64.biz.id",
        "df21-65.biz.id",
        "df21-66.biz.id",
        "df21-67.biz.id",
        "df21-68.biz.id",
        "df21-69.biz.id",
        "df21-70.biz.id",
        "df21-71.biz.id",
        "df21-72.biz.id",
        "df21-73.biz.id",
        "df21-74.biz.id",
        "df21-75.biz.id",
        "df21-76.biz.id",
        "df21-77.biz.id",
        "df21-78.biz.id",
        "df21-79.biz.id",
        "df21-80.biz.id",
        "df21-81.biz.id",
        "df21-82.biz.id",
        "df21-83.biz.id",
        "df21-84.biz.id",
        "df21-85.biz.id",
        "df21-86.biz.id",
        "df21-87.biz.id",
        "df21-88.biz.id",
        "df21-89.biz.id",
        "df21-90.biz.id",
        "df21-91.biz.id",
        "df21-92.biz.id",
        "df21-93.biz.id",
        "df21-94.biz.id",
        "df21-95.biz.id",
        "df21-96.biz.id",
        "df21-97.biz.id",
        "df21-98.biz.id",
        "df21-99.biz.id",
        "df21-100.biz.id"

    )

    // Custom URL scheme dari aplikasi pihak ketiga yang TIDAK boleh trigger
    // crash kalau aplikasinya tidak terinstall (Shopee, Tokopedia, YouTube, dsb).
    // Daftar ini untuk pengecekan eksplisit + log; selain http/https semua
    // tetap di-handle oleh `handleExternalScheme()`.
    private val EXTERNAL_SCHEMES = listOf(
        "intent:", "market:", "tel:", "sms:", "mailto:", "geo:", "whatsapp:",
        "shopee:", "shopeeid:", "tokopedia:", "tokopedia-android-internal:",
        "youtube:", "vnd.youtube:", "fb:", "fb-messenger:", "tg:",
        "instagram:", "twitter:", "tiktok:", "snssdk:", "line:",
        "gojek:", "grab:", "ovo:", "dana:", "gopay:", "blibli:", "lazada:"
    )

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webview)
        progressBar = findViewById(R.id.progressBar)
        swipeRefresh = findViewById(R.id.swipeRefresh)

        setupWebView(webView, isPopup = false)

        // Swipe to refresh - merah brand DF21
        swipeRefresh.setColorSchemeColors(Color.parseColor("#E74C3C"))
        swipeRefresh.setOnRefreshListener { webView.reload() }

        // Back button: tutup popup dulu, baru navigate webview, baru exit
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (popupWindow?.isShowing == true) {
                    closePopup()
                    return
                }
                if (webView.canGoBack()) webView.goBack()
                else finish()
            }
        })

        webView.loadUrl(TARGET_URL)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView(wv: WebView, isPopup: Boolean) {
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            loadWithOverviewMode = true
            useWideViewPort = true
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            mediaPlaybackRequiresUserGesture = false
            setSupportMultipleWindows(true)
            javaScriptCanOpenWindowsAutomatically = true
            // User agent: pakai default + tambah identifier app
            userAgentString = userAgentString.replace("wv", "") + " DF21Live/1.0"
        }

        wv.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                if (!isPopup) progressBar.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String) {
                if (!isPopup) {
                    progressBar.visibility = View.GONE
                    swipeRefresh.isRefreshing = false
                }
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                return handleUrlLoading(view, request.url.toString(), isPopup)
            }

            // Fallback untuk Android < 24 (some redirects masih lewat ini)
            @Suppress("OverridingDeprecatedMember", "DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return handleUrlLoading(view, url, isPopup)
            }

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: WebResourceError
            ) {
                if (request.isForMainFrame && !isPopup) {
                    try {
                        view.loadData(offlineHtml(), "text/html", "UTF-8")
                    } catch (e: Throwable) {
                        Log.d("DF21Live", "loadData offline failed: ${e.message}")
                    }
                }
            }

            // Render process WebView bisa crash dari iklan JS yang berat.
            // Tanpa handler ini, default behaviour-nya adalah crash seluruh app.
            // Override + return true → kita yang handle, app tetap hidup.
            override fun onRenderProcessGone(
                view: WebView,
                detail: RenderProcessGoneDetail
            ): Boolean {
                val didCrash = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    detail.didCrash() else true
                Log.e("DF21Live", "WebView render gone (crash=$didCrash) isPopup=$isPopup")
                if (isPopup) {
                    // Popup mati → tutup popupnya saja
                    closePopup()
                } else {
                    // Main webview mati → recreate activity dengan aman
                    if (!isFinishing && !isDestroyed) {
                        try {
                            (view.parent as? ViewGroup)?.removeView(view)
                            view.destroy()
                        } catch (e: Throwable) { /* ignore */ }
                        try { recreate() } catch (e: Throwable) {
                            Log.e("DF21Live", "recreate failed: ${e.message}")
                        }
                    }
                }
                return true  // kita yang handle, JANGAN crash
            }
        }

        wv.webChromeClient = object : WebChromeClient() {
            private var customView: View? = null
            private var customViewCallback: CustomViewCallback? = null
            private var originalOrientation = 0

            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (!isPopup) progressBar.progress = newProgress
            }

            // window.open / target="_blank" → buka popup di dalam app
            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message
            ): Boolean {
                return try {
                    if (isFinishing || isDestroyed) return false
                    showPopupWebView(resultMsg = resultMsg)
                    true
                } catch (e: Throwable) {
                    Log.e("DF21Live", "onCreateWindow failed: ${e.message}")
                    false
                }
            }

            override fun onCloseWindow(window: WebView) {
                try { closePopup() } catch (e: Throwable) { /* ignore */ }
            }

            // Fullscreen video (HTML5 video)
            override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                try {
                    customView = view
                    customViewCallback = callback
                    originalOrientation = requestedOrientation
                    // Pakai content frame yang lebih aman dari pada decorView cast
                    val container = findViewById<FrameLayout>(android.R.id.content)
                        ?: (window.decorView as? FrameLayout)
                        ?: return
                    container.addView(view, FrameLayout.LayoutParams(-1, -1))
                    @Suppress("DEPRECATION")
                    window.decorView.systemUiVisibility = (
                        View.SYSTEM_UI_FLAG_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    )
                } catch (e: Throwable) {
                    Log.e("DF21Live", "onShowCustomView failed: ${e.message}")
                    try { callback.onCustomViewHidden() } catch (e2: Throwable) { /* ignore */ }
                }
            }

            override fun onHideCustomView() {
                try {
                    customView?.let { v ->
                        val parent = v.parent as? ViewGroup
                        parent?.removeView(v)
                    }
                    customView = null
                    @Suppress("DEPRECATION")
                    window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
                    requestedOrientation = originalOrientation
                    customViewCallback?.onCustomViewHidden()
                } catch (e: Throwable) {
                    Log.e("DF21Live", "onHideCustomView failed: ${e.message}")
                }
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePath: ValueCallback<Array<Uri>>,
                fileChooserParams: FileChooserParams
            ): Boolean {
                return try {
                    filePathCallback?.onReceiveValue(null)
                    filePathCallback = filePath
                    val intent = try { fileChooserParams.createIntent() } catch (e: Throwable) {
                        Log.d("DF21Live", "createIntent failed: ${e.message}")
                        filePathCallback = null
                        return false
                    }
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST)
                    true
                } catch (e: Throwable) {
                    Log.d("DF21Live", "FileChooser failed: ${e.message}")
                    filePathCallback?.onReceiveValue(null)
                    filePathCallback = null
                    false
                }
            }

            override fun onJsAlert(view: WebView, url: String, message: String, result: JsResult): Boolean {
                result.confirm(); return true
            }
        }
    }

    /**
     * Inti dari handling URL — dipanggil dari shouldOverrideUrlLoading.
     *
     * Aturan:
     * 1. URL kosong / null → biarkan default (return false).
     * 2. URL http/https ke domain whitelist → load di WebView (return false).
     * 3. URL http/https ke domain LAIN → buka di browser eksternal kalau bisa,
     *    kalau gagal → ignore (jangan crash).
     * 4. URL custom scheme (intent://, shopee://, tokopedia://, dll.) →
     *    coba buka aplikasi target. Kalau gagal (ANR / aplikasi belum
     *    terinstall) → JANGAN crash, JANGAN redirect ke Play Store yang
     *    annoying, cukup return true (block) supaya WebView nggak coba load
     *    URL tersebut sebagai halaman.
     *
     * Return true = WebView berhenti, kita yang handle.
     * Return false = WebView lanjut load URL tersebut sendiri.
     */
    private fun handleUrlLoading(view: WebView, url: String, isPopup: Boolean): Boolean {
        // OUTER GUARD: apa pun yang terjadi di dalam, JANGAN biarkan crash app.
        // Lebih baik block URL daripada force-close.
        return try {
            if (url.isEmpty()) return false

            val lower = url.lowercase()

            // about:blank, data:, blob: — biarkan WebView handle (ad sering
            // pakai about:blank lalu set location lewat JS)
            if (lower == "about:blank" ||
                lower.startsWith("data:") ||
                lower.startsWith("blob:") ||
                lower.startsWith("javascript:")
            ) {
                return false
            }

            // -------- HTTP / HTTPS --------
            if (lower.startsWith("http://") || lower.startsWith("https://")) {
                // Kalau ini dipanggil dari WebView popup, biarkan apa pun
                // load di popup yang sama — jangan spawn popup di atas popup.
                if (isPopup) return false

                val host = try { Uri.parse(url).host ?: "" } catch (e: Throwable) { "" }
                val isAllowed = ALLOWED_HOSTS.any { allowed ->
                    host == allowed || host.endsWith(".$allowed")
                }
                if (isAllowed) {
                    // Domain whitelist (sbotv.live, df21.biz.id, dll.) → load di main WebView
                    return false
                }

                // Domain luar (iklan popunder, search redirect Google, social, dsb.)
                // → BUKA DI POPUP DALAM APP, bukan browser eksternal.
                // Kalau popup sudah terbuka, load di popup yang sama supaya
                // tidak ada nested popup.
                if (popupWindow?.isShowing == true) {
                    try { popupWebView?.loadUrl(url) } catch (e: Throwable) {
                        Log.d("DF21Live", "Popup loadUrl failed: ${e.message}")
                    }
                } else {
                    showPopupWebView(url = url)
                }
                return true
            }

            // -------- CUSTOM SCHEME (popunder ads target apps) --------
            // Contoh: shopee://, tokopedia://, intent://, market://, youtube://
            handleExternalScheme(url)
        } catch (e: Throwable) {
            // Apa pun yang gagal — log, jangan crash, block URL.
            Log.e("DF21Live", "handleUrlLoading fatal: ${e.javaClass.simpleName}: ${e.message}")
            true
        }
    }

    /**
     * Handle URL dengan scheme non-http (intent://, shopee://, dll.)
     * Selalu return true agar WebView TIDAK mencoba load URL tersebut sebagai
     * halaman web (yang akan menyebabkan error / crash di sebagian Android).
     */
    private fun handleExternalScheme(url: String): Boolean {
        try {
            // Khusus intent:// pakai parser bawaan Android (lebih akurat,
            // bisa parse fallback URL juga)
            if (url.startsWith("intent:", ignoreCase = true) ||
                url.startsWith("android-app:", ignoreCase = true)
            ) {
                val intent: Intent = try {
                    Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                } catch (e: URISyntaxException) {
                    Log.d("DF21Live", "Bad intent URI: $url")
                    return true  // block, malformed
                }
                // Coba buka aplikasi targetnya
                try {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    // Hapus flag ini supaya nggak konflik dgn task baru:
                    intent.component = null
                    intent.selector = null
                    startActivity(intent)
                    return true
                } catch (e: ActivityNotFoundException) {
                    // App tidak terinstall — coba fallback URL kalau ada
                    val fallback = intent.getStringExtra("browser_fallback_url")
                    if (!fallback.isNullOrEmpty()) {
                        // Fallback adalah URL biasa → buka di popup, bukan
                        // langsung di webview (biar tidak ganggu user di main page)
                        if (popupWindow?.isShowing == true) {
                            try { popupWebView?.loadUrl(fallback) } catch (e2: Throwable) { /* ignore */ }
                        } else {
                            showPopupWebView(url = fallback)
                        }
                    }
                    return true
                }
            }

            // Scheme generic (shopee://, youtube://, tokopedia://, market://, dll.)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            // App tidak terinstall — diam saja
            Log.d("DF21Live", "App not installed for: $url")
        } catch (e: SecurityException) {
            // Iklan coba akses scheme yang butuh permission khusus
            Log.d("DF21Live", "SecurityException for $url: ${e.message}")
        } catch (e: URISyntaxException) {
            Log.d("DF21Live", "URI syntax error: $url")
        } catch (e: Throwable) {
            // Tangkap APAPUN yang lain — jangan biarkan crash
            Log.d("DF21Live", "External scheme error: ${e.javaClass.simpleName}: ${e.message}")
        }
        // Selalu return true: kita sudah handle (atau sudah ignore),
        // WebView nggak boleh coba load URL custom-scheme tersebut.
        return true
    }

    // -------- POPUP MODAL (target=_blank / window.open / external URL) --------
    /**
     * Tampilkan popup WebView modal.
     *
     * Dipanggil dari 2 entry point:
     *  1. `onCreateWindow()` — saat web pakai window.open / target=_blank.
     *     Kasus ini WAJIB pakai `resultMsg` agar JS engine kebagian referensi
     *     ke WebView baru (tanpa itu, halaman pemanggil bisa hang menunggu).
     *  2. `handleUrlLoading()` — saat redirect ke domain luar (iklan
     *     popunder ke google.com dll.). Kasus ini pakai `url` langsung.
     */
    // Anti-spam: track timestamp popup terakhir agar iklan nakal yg berkali-kali
    // memanggil window.open dalam waktu pendek tidak bikin app overload.
    private var lastPopupTime: Long = 0L
    private val POPUP_THROTTLE_MS = 800L

    @SuppressLint("SetJavaScriptEnabled")
    private fun showPopupWebView(
        resultMsg: android.os.Message? = null,
        url: String? = null
    ) {
        // GUARD 1: activity sudah ditutup
        if (isFinishing || isDestroyed) {
            Log.d("DF21Live", "showPopupWebView skipped: activity finishing")
            return
        }

        // GUARD 2: rate limit — kalau kurang dari 800ms sejak popup terakhir,
        // load di popup yang sudah ada (kalau masih hidup) atau abaikan.
        val now = System.currentTimeMillis()
        if (now - lastPopupTime < POPUP_THROTTLE_MS) {
            if (popupWindow?.isShowing == true && url != null) {
                try { popupWebView?.loadUrl(url) } catch (e: Throwable) { /* ignore */ }
            }
            return
        }
        lastPopupTime = now

        // GUARD 3: popup yang sebelumnya masih ada → tutup dulu sebelum buat baru
        if (popupWindow?.isShowing == true) {
            try { closePopup() } catch (e: Throwable) { /* ignore */ }
        }

        try {
            buildAndShowPopup(resultMsg, url)
        } catch (e: Throwable) {
            Log.e("DF21Live", "showPopupWebView failed: ${e.javaClass.simpleName}: ${e.message}")
            // Cleanup partial state
            try { popupWebView?.destroy() } catch (e2: Throwable) { /* ignore */ }
            popupWebView = null
            try { popupWindow?.dismiss() } catch (e2: Throwable) { /* ignore */ }
            popupWindow = null
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun buildAndShowPopup(
        resultMsg: android.os.Message?,
        url: String?
    ) {
        val dialog = android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.parseColor("#CC000000")))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setGravity(Gravity.CENTER)
        }

        // Root: tap di luar popup = close
        val rootLayout = FrameLayout(this)
        rootLayout.setBackgroundColor(Color.parseColor("#AA000000"))
        rootLayout.setOnClickListener { closePopup() }

        // Card popup (di tengah)
        val cardLayout = FrameLayout(this)
        cardLayout.setBackgroundColor(Color.parseColor("#141414"))
        cardLayout.elevation = 24f

        val cardParams = FrameLayout.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.93).toInt(),
            (resources.displayMetrics.heightPixels * 0.85).toInt()
        )
        cardParams.gravity = Gravity.CENTER
        cardLayout.layoutParams = cardParams
        // Cegah tap di card menutup popup
        cardLayout.setOnClickListener { /* consume */ }

        // Progress bar popup
        val popupProgress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        popupProgress.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, 6
        )
        popupProgress.progressTintList =
            android.content.res.ColorStateList.valueOf(Color.parseColor("#E74C3C"))

        // WebView popup
        val newWebView = WebView(this)
        newWebView.layoutParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        )
        setupWebView(newWebView, isPopup = true)

        // Override chrome client untuk update progress popup
        newWebView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                popupProgress.progress = newProgress
                popupProgress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }

            override fun onCreateWindow(
                view: WebView,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message
            ): Boolean {
                // ATURAN: link `target=_blank` / `window.open()` di dalam POPUP
                // → buka di BROWSER EKSTERNAL (aplikasi di luar), JANGAN nested
                // popup, JANGAN load di popup yang sama.
                //
                // Cara kerjanya: kita harus tetap kasih JS engine sebuah WebView
                // (kalau resultMsg tidak di-attach, halaman pemanggil bisa hang),
                // jadi kita buat WebView sementara yang hanya buat menangkap URL
                // tujuan, langsung kita lempar ke Intent.ACTION_VIEW, terus
                // WebView temp-nya dibuang.
                return try {
                    val tempWebView = WebView(this@MainActivity)
                    tempWebView.webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(
                            v: WebView,
                            request: WebResourceRequest
                        ): Boolean = redirectExternal(v, request.url.toString())

                        @Suppress("OverridingDeprecatedMember", "DEPRECATION")
                        override fun shouldOverrideUrlLoading(
                            v: WebView,
                            url: String
                        ): Boolean = redirectExternal(v, url)

                        private fun redirectExternal(v: WebView, url: String): Boolean {
                            openInExternalBrowser(url)
                            try {
                                (v.parent as? ViewGroup)?.removeView(v)
                                v.destroy()
                            } catch (e: Throwable) { /* ignore */ }
                            return true
                        }
                    }
                    val transport = resultMsg.obj as? WebView.WebViewTransport
                    if (transport != null) {
                        transport.webView = tempWebView
                        resultMsg.sendToTarget()
                    }
                    true
                } catch (e: Throwable) {
                    Log.e("DF21Live", "Popup onCreateWindow failed: ${e.message}")
                    false
                }
            }
        }

        // Tombol close (X)
        val closeBtn = TextView(this)
        closeBtn.text = "✕"
        closeBtn.textSize = 20f
        closeBtn.setTextColor(Color.WHITE)
        closeBtn.setBackgroundColor(Color.parseColor("#E74C3C"))
        val closeBtnParams = FrameLayout.LayoutParams(dpToPx(44), dpToPx(44))
        closeBtnParams.gravity = Gravity.TOP or Gravity.END
        closeBtn.layoutParams = closeBtnParams
        closeBtn.gravity = Gravity.CENTER
        closeBtn.setOnClickListener { closePopup() }

        // Susun
        cardLayout.addView(newWebView)
        cardLayout.addView(popupProgress)
        cardLayout.addView(closeBtn)
        rootLayout.addView(cardLayout)
        dialog.setContentView(rootLayout)

        // Attach: tergantung dari mana popup dipanggil
        try {
            if (resultMsg != null) {
                // Dari window.open / target=_blank → bridge via WebViewTransport
                val transport = resultMsg.obj as? WebView.WebViewTransport
                if (transport != null) {
                    transport.webView = newWebView
                    resultMsg.sendToTarget()
                } else {
                    Log.d("DF21Live", "WebViewTransport null - skipping bridge")
                }
            } else if (url != null) {
                // Dari redirect domain luar → load URL langsung
                newWebView.loadUrl(url)
            }
        } catch (e: Throwable) {
            Log.e("DF21Live", "Popup attach failed: ${e.message}")
        }

        popupWebView = newWebView
        popupWindow = dialog
        try {
            dialog.show()
        } catch (e: Throwable) {
            Log.e("DF21Live", "Dialog show failed: ${e.message}")
            popupWindow = null
            popupWebView = null
        }
    }

    private fun closePopup() {
        try { popupWebView?.destroy() } catch (e: Throwable) { /* ignore */ }
        popupWebView = null
        try { popupWindow?.dismiss() } catch (e: Throwable) { /* ignore */ }
        popupWindow = null
    }

    /**
     * Buka URL di browser eksternal (aplikasi browser default user).
     * Dipakai untuk nested-popup dari dalam popup: link `target=_blank`
     * di popup → dilempar ke luar app.
     */
    private fun openInExternalBrowser(url: String) {
        if (url.isEmpty() || url == "about:blank") return
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Log.d("DF21Live", "No browser to open: $url")
        } catch (e: Throwable) {
            Log.d("DF21Live", "openInExternalBrowser fail: ${e.message}")
        }
    }

    private fun dpToPx(dp: Int): Int =
        (dp * resources.displayMetrics.density).toInt()

    // -------- ROTATION HANDLING --------
    // Karena kita declare configChanges di manifest, sistem TIDAK akan
    // recreate Activity saat rotasi. Kita di sini cuma log-friendly.
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // WebView otomatis re-layout. Tidak perlu apa-apa lagi.
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == FILE_CHOOSER_REQUEST) {
            val result = if (resultCode == Activity.RESULT_OK && data != null)
                WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null
            filePathCallback?.onReceiveValue(result)
            filePathCallback = null
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    override fun onResume() { super.onResume(); webView.onResume() }
    override fun onPause() { super.onPause(); webView.onPause() }
    override fun onDestroy() {
        closePopup()
        webView.destroy()
        super.onDestroy()
    }

    private fun offlineHtml() = """
        <!DOCTYPE html><html><head><meta charset=UTF-8>
        <meta name=viewport content='width=device-width,initial-scale=1'>
        <style>
          body{background:#0a0a0a;color:#e0e0e0;font-family:sans-serif;
            display:flex;flex-direction:column;align-items:center;
            justify-content:center;min-height:100vh;margin:0;text-align:center;padding:24px}
          .icon{font-size:64px;margin-bottom:16px}
          h2{color:#fff;margin-bottom:8px}
          p{color:#666;margin-bottom:24px;line-height:1.6}
          button{background:#e74c3c;color:#fff;border:none;border-radius:10px;
            padding:14px 28px;font-size:16px;font-weight:700;cursor:pointer}
        </style></head><body>
        <div class=icon>📡</div>
        <h2>Tidak Ada Koneksi</h2>
        <p>Periksa koneksi internet kamu<br>lalu coba lagi.</p>
        <button onclick='location.reload()'>🔄 Coba Lagi</button>
        </body></html>
    """.trimIndent()
}
